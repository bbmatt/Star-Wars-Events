<?php

namespace Yoda\EventBundle\Exception;

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class EventNotFoundHttpException extends NotFoundHttpException
{

}